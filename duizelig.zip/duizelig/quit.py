word = True
while word:
    q = input('gok een woord ')
    if q == 'quit':
        word = False
