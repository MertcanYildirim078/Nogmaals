AM = 0
PM = 12
while AM <12:
    print(AM, ' AM')
    AM += 1
while PM <24:
    print(PM, ' PM')
    PM += 1