week = input('welke dag van de week? ') #ma,di,wo,do,vr,za,zo
while week == 'ma':
    print('ma')
    break
while week == 'di':
    print('ma, di')
    break
while week == 'wo':
    print('ma , di , wo')
    break
while week == 'do':
    print('ma, di, wo, do')
    break
while week == 'vr':
    print('ma, di, wo, do, vr')
    break
while week == 'za':
    print('ma, di, wo, do, vr, za')
    break
while week == 'zo':
    print('ma, di, wo, do, vr, za, zo')
    break