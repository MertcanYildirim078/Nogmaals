print('Raket lancering gestart!')
x = 30
while x >0:
    print(x)
    x -= 1
print('Lancering!')
