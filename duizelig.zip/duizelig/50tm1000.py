x = 50
while x <1001:
    print(x)
    x += 1
