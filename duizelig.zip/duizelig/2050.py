x = 20
while x <52:
    print(x)
    x += 2